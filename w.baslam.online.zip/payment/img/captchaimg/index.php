<?php


error_reporting(0);
session_start() ;
@header('Content-type:image/png');



if(isset($_GET["rnd"])) {
	
	
	switch(rand(1,10)){
		
		case(1):
		
		require("1.jpg");
		
        $_SESSION["captcha"] = 78899;
		
		break ;
		
		case(2):
		
		require("2.jpg");
		
        $_SESSION["captcha"] = 47333;
		
		break ;
		
		case(3):
		
		require("3.jpg");
		
        $_SESSION["captcha"] = 33950;
		
		break ;
		
		case(4):
		
		require("4.jpg");
		
        $_SESSION["captcha"] = 67757;
		
		break ;
		
		case(5):
		
		require("5.jpg");
		
        $_SESSION["captcha"] = 68744;
		
		break ;
		
		case(6):
		
		require("6.jpg");
		
        $_SESSION["captcha"] = 62443;
		
		break ;
		
        case(7):
		
		require("7.jpg");
		
        $_SESSION["captcha"] = 32377;
		
		break ;
		
		
		case(8):
		
		require("8.jpg");
		
        $_SESSION["captcha"] = 54978;
		
		break ;
		
		
		case(9):
		
		require("9.jpg");
		
        $_SESSION["captcha"] = 80536;
		
		break ;
		
		
		case(10):
		
		require("10.jpg");
		
        $_SESSION["captcha"] = 78937;
		
		break ; 
		
		default :  require("captchaimg.jpg") ;
		
		}
	
	} elseif(isset($_GET["default"]) && $_GET["default"] == true ){


         require("default.jpg");
         $_SESSION["captcha"] = 48663;
         

} else {
	
	
http_response_code(403);
	
	} 
	
	



?>