<?php
die(header("Location :https://t.me/XDeragon")) ;
?>